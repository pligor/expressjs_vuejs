var config = require('../../nightwatch.conf.BASIC.js');

module.exports = {
  'Episodes Testing': function (browser) {
    browser
      .url('http://localhost:63342/vue_nightwatch/index.html')
      .waitForElementVisible('body')
      .assert.title('OneFlow Vue.js');

    browser.expect.element('header').to.have.text.equal('Episodes');

    browser.elements('css selector', '.episode', function (res) {
      browser.assert.equal(res.value.length, 38)
    });

    browser.setValue('input.new-episode', ['fi', browser.Keys.UP]);

    browser.assert.containsText('.episode-list', 'Fiduciary Duties');

    browser.expect.element('.episode-list').text.to.not.contain('Minimum Viable Product');

    browser.end();
  }
};