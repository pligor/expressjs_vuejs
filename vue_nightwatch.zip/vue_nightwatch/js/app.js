/*global Vue */

(function (exports) {
  'use strict';

  var filters = {
    all: function (episodes) {
      return episodes;
    }
  };

  exports.app = new Vue({

    // the root element that will be compiled
    el: '.episodeapp',

    // app initial state
    data: {
      episodes: [],
      newTodo: '',
      editedTodo: null,
      visibility: 'all',
      URL: "http://localhost:3000/episodes"
    },

    // watch episodes change
    watch: {
      episodes: {
        deep: true,
        handler: function () {
          //nop
        }
      }
    },

    // computed properties
    // http://vuejs.org/guide/computed.html
    computed: {
      filteredTodos: function () {
        var self = this;
        if (self.newTodo) {
          var newTodo = self.newTodo.toLowerCase();

          return self.episodes.filter(function (episode) {
            //console.log(episode.name.indexOf(self.newTodo));
            return episode.name.toLowerCase().indexOf(newTodo) > -1;
          });
        } else {
          return self.episodes;
        }

      }
    },

    // methods that implement data logic.
    // note there's no DOM manipulation here
    methods: {

    },

    beforeMount: function () {
      var self = this;
      var promise = axios.get(this.URL)
        .then(function (response) {
          self.episodes = response.data
        });
    },

    // a custom directive to wait for the DOM to be updated
    // before focusing on the input field.
    // http://vuejs.org/guide/custom-directive.html
    directives: {
      'episode-focus': function (el, binding) {
        if (binding.value) {
          el.focus();
        }
      }
    }
  });

})(window);
