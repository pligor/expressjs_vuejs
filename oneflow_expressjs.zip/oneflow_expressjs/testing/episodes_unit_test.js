const request = require('supertest');
var assert = require('assert');
var fs = require('fs');
// const express = require('express');

/*const app = express();

app.get('/episodes', function(req, res) {
  res.status(200).json({ name: 'tobi' });
});*/

describe('GET /episodes', function () {
  //var app, getUserStub, request, route;
  var filepath = "/home/student/pligor.george@gmail.com/Desktop/oneflow/data";
  var filename = "saved.json";

  var original_file = filepath + "/" + filename;
  var backup_file = filepath + "/" + filename + "_";

  var keys = ["id", "url", "name", "season", "number", "airdate", "airtime",
    "airstamp", "runtime", "image", "summary"];

  afterEach(function () {
    // runs after all tests in this block
    //restore backed up file
    fs.copyFile(backup_file, original_file, function () {
    });
  });

  it('should throw a 500 error if saved.json is not a valid json', function (done) {
    //backup original file
    fs.copyFile(original_file, backup_file, function () {
      fs.writeFile(original_file, "invalid json body", function () {
        request(require('../app.js'))
          .get('/episodes')
          .expect(500)
          .end(function (err, res) {
            assert.equal(res.statusCode, 500);
            done();
          });

      });
    });
  });

  it('episodes return 200 OK and a json array for all the episodes', function (done) {
    request(require('../app.js'))
      .get('/episodes')
      .expect(200)
      .end(function (err, res) {
        //actually same test as above just to show that the invalid season has no effect

        if (res.body.length > 0) {
          //testing the first and supposing the rest follow the same pattern for speed
          var item = res.body[0];

          var obj_keys = Object.keys(item);

          for (var ii in keys) {
            if (!obj_keys.includes(keys[ii])) {
              assert.fail("key: " + keys[ii] + " is missing")
            }
          }
        }

        assert.equal(res.statusCode, 200);
        done();
      });
  });

  it('episodes return 200 OK and all the episodes if season is invalid', function (done) {
    request(require('../app.js'))
      .get('/episodes?season=4.11') //float is invalid
      .expect(200)
      .end(function (err, res) {
        //expect(res.body).to.equal('pong');

        if (res.body.length > 0) {
          //testing the first and supposing the rest follow the same pattern for speed
          var item = res.body[0];

          var obj_keys = Object.keys(item);

          for (var ii in keys) {
            if (!obj_keys.includes(keys[ii])) {
              assert.fail("key: " + keys[ii] + " is missing")
            }
          }
        }

        assert.equal(res.statusCode, 200);
        done();
      });
  });

  it('episodes return 200 OK and a few episodes if season is valid and specified', function (done) {
    var season = 4;

    request(require('../app.js'))
      .get('/episodes?season=' + season) //float is invalid
      .expect(200)
      .end(function (err, res) {
        //expect(res.body).to.equal('pong');
        var obj = res.body;
        for(var ii in obj) {
          var item = obj[ii];
          assert.equal(item['season'], season)
        }

        assert.equal(res.statusCode, 200);
        done();
      });
  });

  it('episodes return 200 OK and no episodes at all if season is valid but out of range', function (done) {
    var season = 9999999;

    request(require('../app.js'))
      .get('/episodes?season=' + season) //float is invalid
      .expect(200)
      .end(function (err, res) {
        //expect(res.body).to.equal('pong');
        var obj = res.body;
        assert.equal(res.body.length, 0);

        assert.equal(res.statusCode, 200);
        done();
      });
  });
});

/*

describe('Array', function() {
  describe('#indexOf()', function() {
    it('should return -1 when the value is not present', function() {
      assert.equal([1,2,3].indexOf(4), -1);
    });
  });
});*/
