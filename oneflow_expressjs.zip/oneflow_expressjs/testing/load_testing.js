const request = require('supertest');
var assert = require('assert');
var fs = require('fs');
// const express = require('express');

/*const app = express();

app.get('/episodes', function(req, res) {
  res.status(200).json({ name: 'tobi' });
});*/

describe('GET /load', function () {
  //var app, getUserStub, request, route;

  it('index should respond OK', function (done) {
    request(require('../app.js'))
      .get('/')

      .expect(200, function (err, res) {
        //expect(res.body).to.equal('pong');
        done();
      });
  });

  it('index should respond OK', function (done) {
    request(require('../app.js'))
      .get('/')

      .expect(200, function (err, res) {
        //expect(res.body).to.equal('pong');
        done();
      });
  });

  it('load should respond Bad Request(400) if json from url cannot be parsed', function (done) {
    const invalid_json_url = "https://bitbucket.org/pligor/exttestts/raw/d858ebe5e81ad88338022f116d571ca642937f21/invalid.json"
    request(require('../app.js'))
      .get('/load?url=' + invalid_json_url)
      .expect(400, function (err, res) {
        assert.equal(res.statusCode, 400);
        //expect(res.body).to.equal('pong');
        done();
      });
  });

  it('load should respond OK(200) on default request and have "saved.json" file be valid json',
    function (done) {
      request(require('../app.js'))
        .get('/load')
        .expect(200, function (err, res) {
          assert.equal(res.statusCode, 200);
          var filepath = "/home/student/pligor.george@gmail.com/Desktop/oneflow/data/saved.json";

          fs.readFile(filepath, function (err, data) {
            assert.equal(err, null);

            try {
              JSON.parse(data)
            } catch (ee) {
              assert.fail("saved.json file is not a valid json");
              console.log(ee)
            }

            done();
          });
        });
    });
});

/*

describe('Array', function() {
  describe('#indexOf()', function() {
    it('should return -1 when the value is not present', function() {
      assert.equal([1,2,3].indexOf(4), -1);
    });
  });
});*/
