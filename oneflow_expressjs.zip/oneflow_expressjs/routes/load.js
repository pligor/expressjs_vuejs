var express = require('express');
var http = require('http');
var https = require('https');
var router = express.Router();
var fs = require('fs');


//const url = "https://maps.googleapis.com/maps/api/geocode/json?address=Florence"

//TODO this request might be able to speed up. Check later more here:
//https://codeburst.io/4-ways-for-making-http-s-requests-with-node-js-c524f999942d
router.get('/', function (req, response, next) {
  var json_str = "";

  const url = req.query.url || "https://gist.githubusercontent.com/thekiwi/ab70294c8d7ab790d9b6d70df9d3d145/raw/14513c7b841b37b2406dda4d3b9143a25700a68e/silicon-valley.json";

  https.get(url, function (res) {
    res.setEncoding("utf8");

    var body = "";

    res.on("data", function (data) {
      body += data;
      //console.log(body);
      //console.log("e??")
    });

    res.on("end", function () {
      try {
        body = JSON.parse(body);
        json_str = JSON.stringify(body);
      } catch (ee) {
        json_str = null;
      }

      //console.log(json_str);
      fs.writeFile("/home/student/pligor.george@gmail.com/Desktop/oneflow/data/saved.json", json_str, function (err) {
        if (err) {
          console.error(err);
          var status_code = 500;
          response.status(status_code);
          response.render('error', {
            error: {
              status: status_code, stack: "server error"
            }
          });
        } else {
          console.log("json was saved!");

          if (json_str) {
            response.render('generic', {title: 'LOADED:', payload: json_str});
          } else {
            var status_code = 400;
            response.status(status_code);
            response.render('error', {
              error: {
                status: status_code, stack: "json has an invalid format"
              }
            });

            console.log("status code: " + status_code);
          }
        }
      });

    });
  });
});

module.exports = router;
